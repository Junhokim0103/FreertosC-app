﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;
using ZedGraph;

namespace stm32_serial
{
    public partial class Form1 : Form
    {
        SerialPort serial = new SerialPort();
        GraphPane _myPane;
        PointPairList _points;
        private int index = 0;
        private int sonarvalue = 0;
        //public Parity Ｔｅｘｔ { get; private set; }

        public Form1()
        {
            InitializeComponent();
            InitGraph();
            comboBox1.DataSource = SerialPort.GetPortNames();

        }
        public void InitGraph()
        {
            _myPane = zedGraphControl1.GraphPane;
            //타이틀 설정
            _myPane.Title.FontSpec.Size = 15;
            _myPane.Title.Text = "Graph";
            _myPane.Title.FontSpec.IsBold = true;
            //X축 설정
            _myPane.XAxis.Title.FontSpec.Size = 12;
            _myPane.XAxis.Title.Text = "X Axis";
            //실시간으로 Scale 변경 자동으로 하도록
            _myPane.XAxis.Scale.MinAuto = true;
            _myPane.XAxis.Scale.MaxAuto = true;
            _myPane.XAxis.Scale.MajorStepAuto = true;
            _myPane.XAxis.MajorGrid.IsVisible = true;
            _myPane.XAxis.MinorGrid.IsVisible = false;
            _myPane.XAxis.MajorTic.Color = Color.Black;
            //Y축 설정
            _myPane.YAxis.Title.FontSpec.Size = 12;
            _myPane.YAxis.Title.Text = "Y Axis";
            //실시간으로 Scale 변경 자동으로 하도록
            _myPane.YAxis.Scale.MinAuto = true;
            _myPane.YAxis.Scale.MaxAuto = true;
            _myPane.YAxis.Scale.MajorStepAuto = true;
            _myPane.YAxis.MajorGrid.IsVisible = true;
            _myPane.YAxis.MinorGrid.IsVisible = false;
            _myPane.YAxis.MajorTic.Color = Color.Black;
            //그래프 Chart 색, Border 색/굵기 설정
            _myPane.Fill = new Fill(Color.FromArgb(255, 238, 238, 238));
            _myPane.Chart.Fill = new Fill(Color.LightGray, Color.LightGray, 180.0f);
            _myPane.Chart.Border.Color = Color.Black;
            _myPane.Chart.Border.Width = 2;
            //Point 리스트를 그래프 Curve 리스트에 추가
            _points = new PointPairList();
            _myPane.CurveList.Clear();
            LineItem curve = _myPane.AddCurve("Sqrt(X)", _points, Color.Green, SymbolType.None); //라인 범례 이름 Sqrt(X)
            //LineItem curve = _myPane.AddCurve("", _points, Color.Green, SymbolType.None); //라인 범례 없음
            curve.Line.Width = 2;
            _points.Clear();
            zedGraphControl1.AxisChange();
            zedGraphControl1.Invalidate();
            zedGraphControl1.Refresh();
        }
        private void serialHandler(object sender, SerialDataReceivedEventArgs e)
        {
            string data = serial.ReadLine();
            this.Invoke((MethodInvoker)delegate
            {
                string[] parts = data.Trim().Split(',');
                //textBox1.AppendText(data + Environment.NewLine);
                //textBox1.Text = data;
                if((parts.Length == 3) && (int.TryParse(parts[0],out int val1))&& (int.TryParse(parts[1], out int val2)) && (int.TryParse(parts[2], out int val3)))
                //if (int.TryParse(data.Trim(), out int value))
                {
                    sonarvalue = val1;
                    textBox1.Text = val1.ToString();
                    textBox2.Text = val2.ToString();
                    textBox3.Text = val3.ToString();
                    if (val1 >= progressBar1.Minimum && val1 <= progressBar1.Maximum)
                    {
                        progressBar1.Value = val1;
                    }
                    if (val2/100 >= progressBar1.Minimum && val2/100 <= progressBar1.Maximum)
                    {
                        progressBar2.Value = val2/100;
                    }
                    if (val3/100 >= progressBar1.Minimum && val3/100 <= progressBar1.Maximum)
                    {
                        progressBar3.Value = val3/100;
                    }
                }
                
                _points.Add(index++, sonarvalue);
                //실시간으로 그래프 반영하여 보여주기
                zedGraphControl1.AxisChange();
                zedGraphControl1.Invalidate();
                zedGraphControl1.Refresh();

            });
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
           // Serial_Load();
            MessageBox.Show("LED1 toggle");
            //SerialPort serial = new SerialPort(comboBox1.Text,115200);
            //serial.Open();
            serial.Write("LED1\n\r");
            //serial.Close();
            //SerialPort.o
        }


        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("LED2 toggle");
            //SerialPort serial = new SerialPort(comboBox1.Text, 115200);
            //serial.Open();
            serial.Write("LED2\n\r");
            //serial.Close();
        }



        private void button6_Click(object sender, EventArgs e)
        {
            MessageBox.Show("LED3 toggle");
            //SerialPort serial = new SerialPort(comboBox1.Text, 115200);
            //serial.Open();
            serial.Write("LED3\n\r");
            //serial.Close();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            //open
            if (!serial.IsOpen)  //시리얼포트가 열려 있지 않으면
            {
                MessageBox.Show("port open");

                serial.PortName = comboBox1.Text;  //콤보박스의 선택된 COM포트명을 시리얼포트명으로 지정
                serial.BaudRate = int.Parse(comboBox2.SelectedItem.ToString());  //보레이트 변경이 필요하면 숫자 변경하기
                serial.DataBits = 8;
                serial.StopBits = StopBits.One;
                serial.Parity = Parity.None;
                // serial = new SerialPort(comboBox1.Text, int.Parse(comboBox2.SelectedText));
                serial.DataReceived += new SerialDataReceivedEventHandler(serialHandler);
                serial.Open();
                serial.DiscardInBuffer();
            }
            else
            {
                MessageBox.Show("port is already opened");
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            //close
            MessageBox.Show("port closed");
            //SerialPort serial = new SerialPort(comboBox1.Text, 115200);
            //serial.Open();
            //serial.Write("LED3\n\r");
            serial.Close();
        }
    }
}
